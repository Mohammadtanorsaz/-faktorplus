فاکتور پلاس — نسخه قابل نصب وب (PWA)

1) تمام فایل‌های این پوشه را روی یک هاست HTTPS قرار دهید.
2) فایل index.html باید در ریشه سایت باشد.
3) لینک سایت را با Safari در iPhone یا Chrome در Android باز کنید.
4) iPhone: Share > Add to Home Screen
   Android: منوی Chrome > Install app / Add to Home screen

نکته: برای نصب PWA، HTTPS لازم است (به‌جز localhost).
اطلاعات برنامه در localStorage همان مرورگر ذخیره می‌شود؛ برای انتقال دستگاه از بخش «پشتیبان‌گیری» استفاده کنید.
